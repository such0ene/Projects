                       PROJECT TOPIC - MASK VS NO - MASK

WE HAVE TWO NOTEBOOKS:

1. Model1.ipynb 
2. Model2_Model3.ipynb


In notebook 1 :
   We take 1500 images as input convert them into feature vectors and 		perform Logistic Regression Model on the Transformed data.
In notebook 2:
  We take the Transformed data of images from model 1 and performed MLP and 	SVM models on that data.
Common : 
	Data is described and normalized in both notebooks.ROC curves , Countplots , Confusion metrices can also be seen in both notebooks. 
	 
