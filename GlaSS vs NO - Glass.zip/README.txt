                       PROJECT TOPIC - GLASS Vs NO- GLASS CLASSIFICATION

WE HAVE THREE NOTEBOOKS :

1. B19EE075.ipynb 
2. B19EE076.ipynb
3. B18CSE083.ipynb


Step 1: Data Preprocessing
Step 2: Data Cleaning
Step 3: Splitting data into train and test data
Step 4: Model Selection - 
	Logistics Regression(Notebook 1)  
	SVM(Notebook 2)    
	Random forest classifier(Notebook 3)  
Step 5: Dimension reduction -
	PCA (same in all notebooks)
Step 6: Accuracy and cross validation score and plotting ROC - AUC 
	 
